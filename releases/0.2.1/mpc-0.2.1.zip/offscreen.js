// Сигнал капчи по сообщению от SW (PRD §11.1, D58). Никаких других действий у страницы нет.
const SOUNDS = ['alarm', 'siren', 'bell', 'beeps', 'rising'];
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (sender.id !== chrome.runtime.id || !msg || msg.type !== 'offscreen:play') return;
  const id = SOUNDS.includes(msg.sound) ? msg.sound : 'alarm';
  void new Audio(chrome.runtime.getURL(`sounds/captcha-${id}.wav`)).play();
});
